package com.techelevator.model;

public class EstimatedDiameter {

    private Miles miles;

    public Miles getMiles() {
        return miles;
    }

    public void setMiles(Miles miles) {
        this.miles = miles;
    }
}
